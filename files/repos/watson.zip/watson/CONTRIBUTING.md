1. Do not make pull requests on github, I will ignore them.
2. If *you're ready,* email me at my second email.
3. I only read emails encrypted with my public key, and signed with yours.
4. You can find my pgp key where pgp keys are found.
